import UIKit

var str = "Hello, playground"
let flight = (airport:"LAX", airplane:747)
let exampe = {print("yep")}
let fun1:()->(String) = { return "first"}
let fun5:()->(String) = {return "second"}
let fun6:()->(String) = {return "third"}
let fun7:()->(String) = {return "fourth"}
let fun8:()->(String) = {return "fifth"}
let fun2:(String,String)->(String) = {
    (name:String, last:String) in
    //return "second"
    return name + "," + last
}

 let fun3:(String,Int)->(Int) = {
 (airport:String, airplane:Int) in
 return airplane
 }
 
fun1()
let spk = fun2("Roger","Wilco")
print(spk)
print("The \(flight.airport) flight is a \(flight.airplane)")
print("\(fun3(flight.0,3))")

var closureArray = [()->(String)]()
closureArray.append {
    return fun1()
}

/*
closureArray.append {
    print(fun2(str,"yep"))
}
 */

closureArray.append {
    return fun5()
}
closureArray.append {
    return fun6()
}
closureArray.append {
    return fun7()
}
closureArray.append {
    return fun8()
}
var whichOne = Int.random(in: 0...4)
closureArray[0]()
closureArray[1]()
var outString = " "
for index in 1...5 {
    outString += " " + closureArray[whichOne]()
    whichOne = Int.random(in: 0...4)
    outString += " \(index),"
}
outString.removeLast()
print(outString)
